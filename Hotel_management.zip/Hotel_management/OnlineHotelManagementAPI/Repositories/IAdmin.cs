﻿using OnlineHotelManagementAPI.Models;

namespace OnlineHotelManagementAPI.Repositories
{
    public interface IAdmin
    {
        public string AddAdmin(Admin admin);
    }
}
