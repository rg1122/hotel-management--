﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace OnlineHotelManagementAPI.Models
{
    public class Admin
    {
        [Key]
        public string Username { get; set; }

        public string Password { get; set; } 

        public string RefreshToken { get; set; } = string.Empty;

        public DateTime TokenCreated { get; set; }

        public DateTime TokenExpires { get; set; }

        [Required]
        public string Role { get; set; } 
    }
}
